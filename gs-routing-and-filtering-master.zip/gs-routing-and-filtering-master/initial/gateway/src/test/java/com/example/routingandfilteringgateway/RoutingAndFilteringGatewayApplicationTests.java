package com.example.routingandfilteringgateway;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class RoutingAndFilteringGatewayApplicationTests {

	@Test
	public void contextLoads() {
	}

}
